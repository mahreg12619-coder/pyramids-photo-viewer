# Pyramids

A fast, modern desktop photo viewer built with **Go + Wails v3** and a vanilla JS/Canvas frontend.

Images are decoded and downscaled in Go, then streamed to the WebView over HMAC-signed URLs, so full-resolution bitmaps never reach the UI and huge photos open quickly. Each generated preview is stored in a tiny on-disk cache, so a photo is decoded only once — reopening a folder costs a small file read instead of a full decode, which keeps slow HDDs responsive. The old `lxn/walk` build is preserved in `legacy_walk/` as a fallback.

## Features

- Frameless dark window with a custom titlebar and gold "Pyramids" accent
- Multi-image tabs: open several photos at once, each with its own zoom, pan, rotation, filmstrip position, and annotations
- Fast previews: downscale to screen size in Go with a fast filter, JPEG quality 80/72, memory LRU + persistent on-disk cache
- Smooth zoom to cursor (wheel), drag to pan, rotate, fit / 1:1
- Filmstrip of the current folder with lazy-loaded thumbnails and natural sort
- Draw / annotate: freehand pen, six colours, adjustable brush, undo / redo / clear
- **Save copy** writes a PNG next to the original, composited at full resolution
- **Crop**: drag a marquee with handles and aspect locks; the original is replaced after a backup copy is kept
- Keyboard shortcuts and fullscreen
- Drag & drop images onto the window; "Open with" from Explorer works
- Native file / folder pickers
- Supports JPG, PNG, GIF, BMP, TIFF, WebP, PSD/PSB (flattened preview), HEIC/HEIF, AVIF, JPEG XR and ICO/CUR/DDS, with EXIF auto-orientation
- **Opens by content, not by name**: a photo with a missing or misleading extension still opens, and any format Windows can decode works if its codec is installed

## Built for slow disks (HDD)

Pyramids is tuned to open photos quickly even on a mechanical hard drive:

- **Decode once, read forever.** Every generated preview and thumbnail is written to a small on-disk cache in `%LOCALAPPDATA%\Pyramids\preview-cache`. The first view of a photo pays the full decode; every later view is a tiny JPEG read. A folder of thumbnails therefore costs one decode per photo ever, not one per open.
- **Cheap resampling.** Previews and thumbnails use a fast `Linear` filter instead of Lanczos. Saved copies are unaffected: they are composited from the original file at full resolution.
- **Screen-appropriate quality.** Thumbnails encode at JPEG quality 72 and previews at 80 — visually identical on screen, but smaller and faster to produce and transfer.
- **Large photos get a smaller ceiling.** Sources over 10 MB are capped at a 1600px preview (smaller files keep the 4096px ceiling), so a multi-megabyte shot never forces a huge decode just to appear on screen.
- **Gentle prefetch.** Only the *next* photo is warmed, and only after the current one is fully shown, so background work never competes with the photo you asked for.
- **Crop without copying.** Replacing a cropped photo renames the original to a backup and writes the crop in its place, so no full-size bytes are duplicated on disk. Formats that cannot be re-encoded in Go (GIF, WebP, PSD, HEIC) are left untouched and the crop is saved beside them as a PNG.
- **Bounded cache.** The disk cache is trimmed in the background to at most 500 files / 256 MB, oldest first. To reset it, just delete the `preview-cache` folder.

## Requirements

- Go 1.26+
- Node.js 20+ (LTS)
- WebView2 runtime (preinstalled on Windows 10/11)
- Wails v3 CLI:

```powershell
go install github.com/wailsapp/wails/v3/cmd/wails3@v3.0.0
```

Make sure `$(go env GOPATH)\bin` and the Node install directory are on `PATH`.

## Develop

```powershell
$env:Path = "$(go env GOPATH)\bin;C:\Program Files\nodejs;$env:Path"
cd frontend
npm install
cd ..
wails3 dev
```

Hot reload is enabled for both the Go backend and the frontend.

## Build

```powershell
$env:Path = "$(go env GOPATH)\bin;C:\Program Files\nodejs;$env:Path"
wails3 build
```

Output: `bin\pyramids.exe` (self-contained, frontend embedded).

Windows prints a few harmless messages during `wails3 build` (`uname` / `tail` not found, `-VThe system cannot find the file specified.`). The build still exits 0.

## Install

Download or build the setup file and run one of:

| File | Scope | Admin |
| --- | --- | --- |
| `Pyramids-1.3.1-Windows-x64-Setup.exe` | All users, `Program Files` | Yes (UAC prompt) |
| `Pyramids-1.3.1-Windows-x64-Setup-User.exe` | Current user, `%LOCALAPPDATA%\Programs\Pyramids` | No |

Both create a Start Menu entry, a desktop shortcut, and an uninstaller. If the WebView2 runtime is missing, the installer downloads and installs it silently. Uninstall via **Settings → Apps → Pyramids**, or `uninstall.exe` in the install folder.

`Pyramids-1.3.1-Windows-x64-Portable.zip` needs no installation — extract it anywhere and run `Pyramids.exe`.

Upgrading is the same as installing: run the newer setup. It replaces the previous files in place; your photos and annotated copies are never touched.

Because the installers are not code-signed yet, Windows SmartScreen may show **"Windows protected your PC"**. Choose **More info → Run anyway**, or sign the binaries before publishing (see below). `SHA256SUMS.txt` lets people verify downloads.

The installer also registers Pyramids as the **default app** for JPG, JPEG, PNG, GIF, BMP, TIFF, WebP, PSD, PSB, HEIC, HEIF, AVIF and JXR image files (`Software\Classes` per-extension entries; the previous default is backed up and restored on uninstall). You can always change this later in **Settings → Default apps**.

## Publish a release

One command builds everything into `dist\`:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\release.ps1
```

Add `-SkipTests` to skip the Go test run. The script:

1. runs `go test ./`
2. builds the machine-wide installer
3. builds the per-user installer
4. creates the portable ZIP (app + README)
5. writes `SHA256SUMS.txt`

Result:

```
dist\
  Pyramids-1.3.1-Windows-x64-Setup.exe
  Pyramids-1.3.1-Windows-x64-Setup-User.exe
  Pyramids-1.3.1-Windows-x64-Portable.zip
  SHA256SUMS.txt
```

### Bump the version

Edit the version in **one** place — `build/config.yml` — then refresh the generated installer metadata before releasing:

```powershell
# edit: build/config.yml -> info.version: "1.3.2"
wails3 task common:update:build-assets
.\release.ps1
```

`release.ps1` refuses to run if `build/config.yml` and the NSIS metadata disagree, so installers can't be stamped with a stale version.

### Code signing (removes SmartScreen warnings)

Unsigned installers are fine for personal use, but public releases should be signed with an Authenticode certificate or Azure Trusted Signing.

```powershell
wails3 setup signing          # store certificate + password once
wails3 task windows:sign      # signs bin\pyramids.exe
wails3 task windows:sign:installer
```

Then rebuild the artifacts with `.\release.ps1`. Sign after building each installer, or configure signing in `build/windows/Taskfile.yml` (the `SIGN_CERTIFICATE` / `SIGN_THUMBPRINT` variables are already wired up).

### Put it on GitHub Releases

1. Create the repo and push the source.
2. Create a tag, e.g. `v1.3.1`.
3. Run `.\release.ps1`.
4. Create a GitHub Release for the tag and attach the three files from `dist\` (not `SHA256SUMS.txt` alone — attach it too).
5. Paste the contents of `SHA256SUMS.txt` into the release notes so users can verify.

## Tests

```powershell
go test ./
```

Covers preview serving, signed-token tampering (including non-canonical encodings), natural folder sort, PNG → JPEG conversion, annotated-copy export (full-resolution compositing, collision-safe names, invalid payloads), PSD/HEIC decoding, content sniffing for mislabelled files, multi-frame ICO selection, the 32-bit BGR pixel layout AVIF decoders emit, missing-codec messages, and cropping (in-place replacement, JPEG aliases, backup naming, the PNG-copy fallback for formats that cannot be re-encoded, and rejected rectangles).

## Project layout

```
main.go                     Wails app, frameless window, drag-drop bridge, logging
imageservice.go             decode / downscale / cache, signed /img handler, folder listing, annotated export, crop
formats.go                  format dispatch: content sniffing, native decoders, PSD composite reader
wic.go                      Windows Imaging Component decoder (HEIC/AVIF/JPEG XR/ICO/DDS) with manual pixel conversion
imageservice_test.go        backend tests
formats_test.go             PSD / WIC / format-routing tests
crop_test.go                crop tests (backups, copy fallback, bad rectangles)
release.ps1                 builds installers + portable ZIP + checksums into dist\
frontend/index.html         UI markup (titlebar, tabs, stage, draw + crop panels, filmstrip, toolbar)
frontend/public/style.css   dark theme, gold accent, tabs, draw/crop panels, layout
frontend/src/main.js        per-tab viewer state, canvas zoom/pan, drawing, cropping, shortcuts, Wails events
frontend/bindings/          generated JS bindings (regenerate with wails3 generate bindings)
build/config.yml            product metadata (name, identifier, version)
build/appicon.png           app icon source (1024x1024 PNG)
build/windows/icon.ico      generated Windows icon
build/windows/nsis/         NSIS installer script and generated metadata
legacy_walk/                preserved old lxn/walk viewer (fallback)
```

## Replace the app icon

1. Put a square 1024×1024 PNG at `build/appicon.png`.
2. Regenerate the Windows icon and rebuild:

```powershell
wails3 generate icons -input build\appicon.png -windowsfilename build\windows\icon.ico
wails3 build
```

The installer icon comes from `build\windows\icon.ico`, so run `wails3 task common:update:build-assets` too if you want `dist\` installers updated.

## Keyboard shortcuts

| Key | Action |
| --- | --- |
| `←` / `→`, `PageUp` / `PageDown` | Previous / next image |
| `+` / `-` | Zoom in / out |
| Mouse wheel | Zoom to cursor |
| Drag | Pan |
| Double-click | Toggle fit / 1:1 |
| `0` | Fit to window |
| `1` | Actual size (1:1) |
| `R` | Rotate 90° |
| `F` | Fullscreen |
| `D` | Toggle draw / annotate |
| `C` | Toggle crop |
| `Enter` | Apply the crop |
| `Ctrl+Z` | Undo stroke |
| `Ctrl+Y` / `Ctrl+Shift+Z` | Redo stroke |
| `Space` + drag | Pan while drawing |
| `Ctrl+W` | Close current tab |
| `Ctrl+Tab` / `Ctrl+Shift+Tab` | Next / previous tab |
| `Esc` | Leave crop or draw mode / fullscreen, or refit |
| `Ctrl+O` | Open image in a new tab |

## Tabs and annotations

- Opening an image from the dialog, drag-and-drop, or **Open with** creates a tab. Opening the same file again just switches to its tab.
- Browsing with the filmstrip or arrow keys reuses the current tab while it has no annotations. Once you draw, the tab is kept (marked with a gold dot) and the next image opens in a new tab.
- Each tab remembers its own zoom, pan, rotation, drawing mode, and strokes. Closing a tab with annotations asks for confirmation.
- **Save copy** writes `photo - annotated.png` beside the original (then `- annotated 2.png`, and so on). The annotation layer is composited onto the full-resolution photo in Go, so the copy keeps the original dimensions and detail.
- Draw in image coordinates: zooming or panning after drawing keeps strokes aligned. The saved copy is always unrotated; rotation is a view-only setting.

## Cropping

- Press `C` (or the crop button) to open the crop tool. A marquee appears over the photo.
- Drag the corners or edges to resize, drag inside the marquee to move it, or press outside it to start a fresh rectangle. The `1:1`, `4:3` and `16:9` buttons lock the aspect ratio (`Free` unlocks it).
- **Enter** or **Apply** crops the file; **Esc** or **Cancel** leaves it untouched.
- The marquee is drawn on the screen-sized preview, but the crop itself is cut from the **full-resolution original**, so no detail is lost.
- Before a photo is replaced it is renamed to `photo - backup.jpg` (`- backup 2.jpg`, and so on), so a crop can always be undone. **JPG (and the `.jpeg`/`.jpe`/`.jfif`/`.jif` spellings), PNG, BMP and TIFF** are written back in their own format.
- **GIF, WebP, PSD, HEIC, AVIF, JPEG XR, ICO, CUR, DDS** and mislabelled files cannot be re-encoded in pure Go, so those originals are left alone and the crop is saved beside them as `photo - cropped.png`.
- Cropping needs an upright view: the tool is disabled while the image is rotated. A crop also clears the tab's annotations, because they were drawn against the old dimensions.
- The tab reloads with the cropped image and its folder position is kept.

## Notes and limits

- Previews are always JPEG, so transparent PNGs get a solid background.
- Animated GIFs show the first frame only; annotated copies are saved as PNG.
- Rotation is view-only. The only operation that modifies a photo is **Crop**, and it always keeps a backup copy first. **Save copy** always writes a separate file.
- PSD/PSB files show Photoshop's flattened composite. Layers are not editable, and exotic variants (16-bit, CMYK, very large PSB) may be refused with an error instead of guessed at.
- HEIC/HEIF, AVIF, JPEG XR, ICO/CUR and DDS decoding all use the Windows Imaging Component. JPEG XR, icons and DDS work out of the box on any Windows 10/11.
- **HEIC and AVIF need a codec Windows does not always ship.** Both are containers around a *video* codec, so Windows needs two pieces: the container extension plus the HEVC or AV1 decoder. On Windows 11 the free **HEIF Image Extension** and **AV1 Video Extension** from the Microsoft Store are usually enough. On Windows 10 the **AV1 Video Extension** is required for AVIF, and HEIC additionally needs an HEVC decoder, which is a separate (sometimes paid) Microsoft package. When a decoder is missing the app says exactly which package to install instead of showing a raw error code.
- If Windows recognises a file's container but has no decoder for the data inside it, Pyramids reports that plainly: the photo is not corrupt, the codec is missing.
- Because decoding follows the file's contents, a photo with a wrong or missing extension opens normally — but such files are not listed in the filmstrip, which only shows known image extensions. Probing every unknown file in a folder would cost a disk read each, which is exactly what Pyramids avoids on an HDD. Use **Open image** or drag & drop for those.
- Exotic pixel formats that Windows exposes through a codec but that the app cannot convert without loss (for example HDR JPEG XR, 16-bit, or CMYK variants) are refused with a clear message rather than shown in wrong colours.
- Signing keys are generated per run, so preview URLs are not stable across restarts (they are only used within a session).
- Logs: `%LOCALAPPDATA%\Pyramids\pyramids.log`.
